# MeanMedianMode
solution 104
